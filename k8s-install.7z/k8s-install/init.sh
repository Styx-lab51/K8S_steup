
echo '192.168.200.210   node01' >> /etc/hosts
echo '192.168.200.220   node02 cnflab.lab' >> /etc/hosts
echo '192.168.200.230   controller' >> /etc/hosts

# Disable SWAP:

echo '|------ disabling SWAP ------|'
echo ''
swapoff -a
sed -i '/swap/d' /etc/fstab
cat /etc/fstab


echo '|------ Kernel Config ------|'
echo ''

cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF
sudo modprobe overlay
sudo modprobe br_netfilter
# sysctl params required by setup, params persist across reboots
cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-iptables = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward = 1
EOF

sudo sysctl --system


echo '|------ Install Containerd.io ------|'
echo ''
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y containerd.io


echo '|------ copy config files ------|'
echo ''
sudo cp configfiles/config.toml /etc/containerd/
sudo cp configfiles/crictl.yaml /etc/
sudo cp configfiles/registries.conf /etc/containers/

echo '|------ enable/disable needed services ------|'
echo ''
# stop firewalld (for lab only)

sudo systemctl disable firewalld
sudo systemctl stop firewalld

sudo systemctl enable containerd
sudo systemctl start containerd

echo '|------ Install Kubernetes ------|'
echo ''
cat <<EOF | sudo tee /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://pkgs.k8s.io/core:/stable:/v1.29/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/v1.29/rpm/repodata/repomd.xml.key
exclude=kubelet kubeadm kubectl cri-tools kubernetes-cni
EOF

yum install -y kubelet kubeadm kubectl --disableexcludes=kubernetes
systemctl enable --now kubelet

echo '|------ Install helm ------|'
echo ''
yum install git -y
./get_helm.sh

echo '|------ Base Config DONE ------|'
